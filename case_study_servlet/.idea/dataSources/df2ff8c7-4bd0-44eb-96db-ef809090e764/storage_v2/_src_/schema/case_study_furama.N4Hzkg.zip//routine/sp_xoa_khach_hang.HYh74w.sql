create
    definer = root@localhost procedure sp_xoa_khach_hang(IN ma_khach_hang_del int)
begin
    set sql_safe_updates = 0;
    set foreign_key_checks = 0;
    delete from khach_hang where ma_khach_hang = ma_khach_hang_del;
    set foreign_key_checks = 1;
    set sql_safe_updates = 1;
end;

