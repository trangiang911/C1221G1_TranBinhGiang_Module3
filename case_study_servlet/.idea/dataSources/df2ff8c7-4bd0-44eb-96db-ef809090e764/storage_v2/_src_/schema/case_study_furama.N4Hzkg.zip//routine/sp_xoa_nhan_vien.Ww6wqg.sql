create
    definer = root@localhost procedure sp_xoa_nhan_vien(IN ma_nhan_vien_del int)
begin
    set sql_safe_updates = 0;
    set foreign_key_checks = 0;
    delete from nhan_vien where ma_nhan_vien = ma_nhan_vien_del;
    set foreign_key_checks = 1;
    set sql_safe_updates = 1;
end;

