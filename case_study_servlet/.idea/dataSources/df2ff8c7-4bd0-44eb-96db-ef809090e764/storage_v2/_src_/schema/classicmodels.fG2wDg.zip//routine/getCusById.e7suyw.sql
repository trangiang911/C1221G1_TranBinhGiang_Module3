create
    definer = root@localhost procedure getCusById(IN cusNum int)
BEGIN

  SELECT * FROM customers WHERE customerNumber = cusNum;

END;

