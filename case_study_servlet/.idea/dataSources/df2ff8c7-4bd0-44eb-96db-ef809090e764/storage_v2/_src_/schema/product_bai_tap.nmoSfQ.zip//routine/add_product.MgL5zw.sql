create
    definer = root@localhost procedure add_product(IN code varchar(25), IN name varchar(25), IN price double,
                                                   IN amount int, IN description varchar(50), IN status bit)
begin
    insert into products_1(product_code,product_name,product_price,product_amount,product_description,product_status) value
    (code,name,price,amount,description,status);
end;

