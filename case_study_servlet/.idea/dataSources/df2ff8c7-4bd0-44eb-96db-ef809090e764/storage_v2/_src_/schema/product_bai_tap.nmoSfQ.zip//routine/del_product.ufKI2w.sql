create
    definer = root@localhost procedure del_product(IN id_del int)
begin
    delete from products_1 where id=id_del;
end;

