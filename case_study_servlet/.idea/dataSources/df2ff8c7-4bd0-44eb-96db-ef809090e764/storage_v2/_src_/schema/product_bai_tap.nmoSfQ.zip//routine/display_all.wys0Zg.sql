create
    definer = root@localhost procedure display_all()
begin
    select * from products_1;
end;

