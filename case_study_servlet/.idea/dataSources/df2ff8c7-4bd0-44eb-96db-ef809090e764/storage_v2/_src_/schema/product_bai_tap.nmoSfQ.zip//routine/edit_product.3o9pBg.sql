create
    definer = root@localhost procedure edit_product(IN id_edit int, IN ma_sp varchar(25), IN name varchar(25),
                                                    IN price double, IN amount int, IN description varchar(50),
                                                    IN status bit)
begin
    update
        products_1
            set product_code=`ma_sp`,product_name=`name`,product_price=`price`,product_amount=`amount`,product_description=`description`,product_status=`status`
    where id=`id_edit`;
end;

